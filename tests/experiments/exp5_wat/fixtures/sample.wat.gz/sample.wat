WARC/1.0
WARC-Type: metadata
WARC-Record-ID: <urn:uuid:607d2a57-1057-4848-b42b-76853f8ffaf2>
WARC-Target-URI: http://src1.com/page
WARC-Date: 2026-06-13T15:27:15Z
WARC-Payload-Digest: sha1:QXEDGDSI4ROYAPW6BJGVCXFWXP26TAVA
WARC-Block-Digest: sha1:QXEDGDSI4ROYAPW6BJGVCXFWXP26TAVA
Content-Type: application/json
Content-Length: 294

{"Envelope": {"WARC-Header-Metadata": {"WARC-Target-URI": "http://src1.com/page"}, "Payload-Metadata": {"HTTP-Response-Metadata": {"HTML-Metadata": {"Links": [{"path": "A@/href", "url": "https://a.bg/x", "text": "buy", "rel": "nofollow"}, {"path": "IMG@/src", "url": "https://a.bg/i.png"}]}}}}}

WARC/1.0
WARC-Type: metadata
WARC-Record-ID: <urn:uuid:7f91d782-5cd3-4fab-8e7f-beb3bb1fe94d>
WARC-Target-URI: http://src1.com/other
WARC-Date: 2026-06-13T15:27:15Z
WARC-Payload-Digest: sha1:XIRNK6BUQ4B7NP7D2NCJHN42J4FJYAK5
WARC-Block-Digest: sha1:XIRNK6BUQ4B7NP7D2NCJHN42J4FJYAK5
Content-Type: application/json
Content-Length: 226

{"Envelope": {"WARC-Header-Metadata": {"WARC-Target-URI": "http://src1.com/other"}, "Payload-Metadata": {"HTTP-Response-Metadata": {"HTML-Metadata": {"Links": [{"path": "A@/href", "url": "https://x.net/y", "text": "out"}]}}}}}

